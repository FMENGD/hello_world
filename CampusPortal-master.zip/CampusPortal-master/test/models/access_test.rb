require 'test_helper'

class AccessTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
