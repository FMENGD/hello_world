require 'test_helper'

class AccountActivationsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
