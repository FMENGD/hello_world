require 'test_helper'

class AccessControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
