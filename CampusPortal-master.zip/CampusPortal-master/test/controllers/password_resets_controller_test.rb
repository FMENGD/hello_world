require 'test_helper'

class PasswordResetsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
