class ApplicationMailer < ActionMailer::Base
  default from: "pzq8300885@163.com"
  layout 'mailer'
end
